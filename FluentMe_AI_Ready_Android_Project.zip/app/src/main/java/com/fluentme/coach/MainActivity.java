package com.fluentme.coach;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 7213;
    private static final String ORIGIN = "https://appassets.androidplatform.net/assets/";
    private WebView browser;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xff0b1020);
        getWindow().setNavigationBarColor(0xff121a2f);
        browser = new WebView(this);
        setContentView(browser);
        WebSettings ws = browser.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        browser.addJavascriptInterface(new NativeBridge(), "FluentNative");
        PracticeAlarm.createChannel(this);
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                String path = req.getUrl().toString();
                if (!path.startsWith(ORIGIN)) return super.shouldInterceptRequest(view, req);
                String file = path.substring(ORIGIN.length());
                if (!file.matches("[a-zA-Z0-9._/-]+") || file.contains("..")) return null;
                try {
                    InputStream stream = getAssets().open(file);
                    String mime=file.endsWith(".js")?"application/javascript":file.endsWith(".css")?"text/css":file.endsWith(".svg")?"image/svg+xml":file.endsWith(".webmanifest")?"application/manifest+json":"text/html";
                    return new WebResourceResponse(mime,"UTF-8",stream);
                } catch(Exception ignored) { return null; }
            }
        });
        tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(Locale.US);});
        browser.loadUrl(ORIGIN+"index.html");
    }
    // Exposed only to our locally packaged page. Do not navigate this WebView to untrusted pages.
    final class NativeBridge {
        @JavascriptInterface public void listen(){ runOnUiThread(()->{
            try {
                Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak English now");
                startActivityForResult(i,SPEECH_REQUEST);
            }catch(ActivityNotFoundException ex){resultError("Speech recognition is not installed. You can still type.");}
        }); }
        @JavascriptInterface public void setDailyReminder(String time){
            runOnUiThread(()->{
                try {
                    PracticeAlarm.setDaily(MainActivity.this,time);
                    if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},909);
                    }
                } catch(Exception e){Toast.makeText(MainActivity.this,"Reminder could not be scheduled",Toast.LENGTH_LONG).show();}
            });
        }
        @JavascriptInterface public void cancelDailyReminder(){runOnUiThread(()->PracticeAlarm.cancel(MainActivity.this));}
        @JavascriptInterface public void showReminderNow(){runOnUiThread(()->{
            if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},909);
            else PracticeAlarm.notifyNow(MainActivity.this);
        });}
        @JavascriptInterface public void speak(String text){
            if(text==null)return;
            final String safe=text.length()>2000?text.substring(0,2000):text;
            runOnUiThread(()->{if(tts!=null)tts.speak(safe,TextToSpeech.QUEUE_FLUSH,null,"fluentme_utterance");});
        }
    }
    private String quoted(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\u2028","\\u2028").replace("\u2029","\\u2029")+"\"";}
    private void resultError(String message){ if(browser!=null)browser.evaluateJavascript("window.fluentVoiceError("+quoted(message)+")",null); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=SPEECH_REQUEST)return;
        if(resultCode==RESULT_OK&&data!=null){ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(words!=null&&!words.isEmpty()){
            browser.evaluateJavascript("window.fluentVoiceResult("+quoted(words.get(0))+")",null);return;
        }}
        resultError("No speech recognised. Try again or use text.");
    }
    @Override public void onBackPressed(){
        if (browser==null) {super.onBackPressed();return;}
        browser.evaluateJavascript("(function(){var s=document.querySelector('.view.active');if(s&&s.id!=='home'){document.querySelector('[data-go=home]').click();return true}return false})()", result -> {
            if (!"true".equals(result)) MainActivity.super.onBackPressed();
        });
    }
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}if(browser!=null)browser.destroy();super.onDestroy();}
}
